#!/bin/bash
# Wrapper instal Bot Telegram Darren (bot-js) — nama lama, isi sama dengan install-botjs.
# Installer asli: /usr/bin/install-botjs (disalin install.sh) atau
# /root/darren-install/v4-main/install-bot.sh.
clear
if [ -x /usr/bin/install-botjs ]; then
  exec bash /usr/bin/install-botjs "$@"
fi
if [ -f /root/darren-install/v4-main/install-bot.sh ]; then
  exec bash /root/darren-install/v4-main/install-bot.sh "$@"
fi
echo "Installer bot tidak ditemukan."
echo "Jalankan install.sh dulu, atau pastikan source ada di /root/darren-install/v4-main/install-bot.sh"
read -n 1 -s -r -p "Tekan tombol apa saja untuk kembali ke menu"
menu
